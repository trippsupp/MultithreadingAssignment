import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;


/**
 * Reads and formats the contents of a text file
 * 
 * @author Vance Field
 * @version 5-Apr-2016
 */
public class Reader implements Runnable{
    
    OutputWindow ow = new OutputWindow();
    String output = "";
    String tempOutput = "";
    String fileName;
    FileReader file;
    Scanner scanner;
    public int wordCount = 0;
    String line;
    Scanner lineScan;
    
    /**
     * Constructor
     * 
     * @param _path path of the file
     * @param _fileName name of the file
     * @throws FileNotFoundException 
     */
    public Reader(String _path, String _fileName) throws FileNotFoundException{
        file = new FileReader(_path);
        scanner = new Scanner(file);
        fileName = _fileName;
        //System.out.println("Inside the Reader Constructor");
    }
    
    /**
     * Runs each time the thread is started
     */
    public void run() {        
        try {
            //System.out.println("Inside the run() method");
            while(scanner.hasNext()){ // while another line
                line = scanner.nextLine(); // take the line 
                lineScan = new Scanner(line); // scan the line
                while(lineScan.hasNext()){ // while another word in the line
                    tempOutput += lineScan.next() + " "; // add word to output
                    wordCount++; // count each word
                }
                tempOutput += "\n"; // at the end of each line add a new line
            }
            
            // formats the output
            output = "Filename: " + fileName 
                    + "\n\nThe word count is: " + wordCount 
                    + "\n\nFile contents:\n\n" + tempOutput;
            
            // creates a new window with the output of the file
            ow.createWindow(output,fileName);
            
        } catch(Exception er){
            er.printStackTrace();
        }
    }    
}
